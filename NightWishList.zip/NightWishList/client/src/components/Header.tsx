export default function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-foreground/10">
      <div className="max-w-7xl mx-auto px-6 md:px-12 h-20 flex items-center justify-between">
        <h1 
          className="text-sm md:text-base font-normal tracking-[0.3em] uppercase text-foreground" 
          style={{ fontFamily: 'var(--font-serif)' }}
          data-testid="text-header-title"
        >
          Wishlist
        </h1>
        <div className="flex items-center gap-8 md:gap-12">
          <a
            href="#wishlist"
            className="text-xs md:text-sm tracking-[0.2em] uppercase text-foreground/60 hover:text-foreground transition-colors duration-300"
            data-testid="link-wishlist"
          >
            Items
          </a>
          <a
            href="#contact"
            className="text-xs md:text-sm tracking-[0.2em] uppercase text-foreground/60 hover:text-foreground transition-colors duration-300"
            data-testid="link-contact"
          >
            Contact
          </a>
        </div>
      </div>
    </header>
  );
}
