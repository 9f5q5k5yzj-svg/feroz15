import { useEffect, useRef, useState } from "react";

export default function IntroSection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-24 md:py-32 px-6 bg-white">
      <div className={`max-w-4xl mx-auto text-center space-y-10 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
        {/* Headline */}
        <h2 
          className="text-4xl md:text-6xl lg:text-7xl font-normal text-foreground tracking-tight leading-tight"
          style={{ fontFamily: 'var(--font-serif)' }}
          data-testid="text-intro-headline"
        >
          A Collection of Dreams
        </h2>

        {/* Body text */}
        <p 
          className="text-base md:text-lg text-foreground/60 tracking-wide leading-relaxed max-w-2xl mx-auto"
          data-testid="text-intro-body"
        >
          These are some things that would make turning fifteen even more special. 
          Each item represents a piece of what brings joy, inspiration, and excitement 
          to this journey.
        </p>
      </div>

      {/* Full width divider at bottom */}
      <div className="full-divider mt-24 md:mt-32" />
    </section>
  );
}
