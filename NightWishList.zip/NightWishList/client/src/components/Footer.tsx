import { Instagram, Mail, Phone } from "lucide-react";

export default function Footer() {
  return (
    <footer 
      id="contact"
      className="relative py-20 md:py-24 bg-white"
    >
      {/* Clean top divider - aligned perfectly */}
      <div className="absolute top-0 left-0 right-0 h-px bg-foreground/15" />

      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col items-center gap-12">
          <h3 
            className="text-sm md:text-base tracking-[0.3em] uppercase text-foreground"
            style={{ fontFamily: 'var(--font-serif)' }}
          >
            Get in Touch
          </h3>
          
          <div className="flex flex-wrap items-center justify-center gap-8 md:gap-12">
            {/* Email */}
            <button
              className="group flex items-center gap-3 text-sm tracking-wide text-foreground/70 hover:text-foreground transition-colors duration-300"
              onClick={() => window.location.href = 'mailto:birthday@example.com'}
              data-testid="button-email"
            >
              <Mail className="h-4 w-4 transition-transform group-hover:scale-110" />
              <span className="tracking-widest">EMAIL</span>
            </button>

            {/* Divider */}
            <div className="w-px h-5 bg-foreground/15" />

            {/* Phone */}
            <button
              className="group flex items-center gap-3 text-sm tracking-wide text-foreground/70 hover:text-foreground transition-colors duration-300"
              onClick={() => window.location.href = 'tel:+1234567890'}
              data-testid="button-phone"
            >
              <Phone className="h-4 w-4 transition-transform group-hover:scale-110" />
              <span className="tracking-widest">PHONE</span>
            </button>

            {/* Divider */}
            <div className="w-px h-5 bg-foreground/15" />

            {/* Instagram */}
            <button
              className="group flex items-center gap-3 text-sm tracking-wide text-foreground/70 hover:text-foreground transition-colors duration-300"
              onClick={() => window.open('https://instagram.com/username', '_blank')}
              data-testid="button-instagram"
            >
              <Instagram className="h-4 w-4 transition-transform group-hover:scale-110" />
              <span className="tracking-widest">INSTAGRAM</span>
            </button>
          </div>

          {/* Bottom text */}
          <p className="text-xs text-foreground/40 text-center tracking-[0.2em] mt-6 uppercase">
            Thank you for celebrating this day
          </p>
        </div>
      </div>
    </footer>
  );
}
