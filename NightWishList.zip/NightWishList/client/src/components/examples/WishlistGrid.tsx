import WishlistGrid from '../WishlistGrid';

export default function WishlistGridExample() {
  return <WishlistGrid />;
}
