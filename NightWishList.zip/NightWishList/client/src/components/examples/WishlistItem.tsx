import WishlistItem from '../WishlistItem';

export default function WishlistItemExample() {
  return (
    <div className="p-8 max-w-sm">
      <WishlistItem
        id="1"
        image="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80"
        title="Vintage Camera"
        description="A classic film camera to capture those nighttime city moments with authentic grain and glow."
        price="$299"
        link="https://example.com"
      />
    </div>
  );
}
