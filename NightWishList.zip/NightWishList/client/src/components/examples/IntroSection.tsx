import IntroSection from '../IntroSection';

export default function IntroSectionExample() {
  return <IntroSection />;
}
