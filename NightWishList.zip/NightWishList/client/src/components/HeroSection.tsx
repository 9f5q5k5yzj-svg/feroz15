export default function HeroSection() {
  return (
    <section className="relative h-screen flex flex-col items-center justify-center overflow-hidden bg-white pt-20">
      {/* Video Background - User will replace this with their own video */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover opacity-15"
        data-testid="video-background"
      >
        {/* TODO: User should replace this with their own video file */}
        {/* <source src="/path/to/your/video.mp4" type="video/mp4" /> */}
      </video>

      {/* Subtle blue overlay for digicam night vibe */}
      <div 
        className="absolute inset-0 pointer-events-none mix-blend-multiply opacity-[0.03]"
        style={{
          background: 'radial-gradient(circle at 40% 50%, hsl(210, 100%, 50%), transparent 70%)',
        }}
      />

      {/* Film grain texture */}
      <div 
        className="absolute inset-0 opacity-[0.04] pointer-events-none mix-blend-overlay"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />

      {/* Marquee Text - Properly centered */}
      <div className="relative z-10 w-full overflow-hidden flex-shrink-0">
        <div className="flex animate-marquee-fast md:animate-marquee" style={{ width: 'fit-content' }}>
          <div className="flex whitespace-nowrap" style={{ width: 'fit-content' }}>
            <span 
              className="text-7xl md:text-8xl lg:text-[12rem] font-normal text-foreground px-8 md:px-16 tracking-tight inline-block" 
              style={{ fontFamily: 'var(--font-serif)' }}
            >
              FIFTEEN •{' '}
            </span>
            <span 
              className="text-7xl md:text-8xl lg:text-[12rem] font-normal text-foreground px-8 md:px-16 tracking-tight inline-block" 
              style={{ fontFamily: 'var(--font-serif)' }}
            >
              FIFTEEN •{' '}
            </span>
            <span 
              className="text-7xl md:text-8xl lg:text-[12rem] font-normal text-foreground px-8 md:px-16 tracking-tight inline-block" 
              style={{ fontFamily: 'var(--font-serif)' }}
            >
              FIFTEEN •{' '}
            </span>
            <span 
              className="text-7xl md:text-8xl lg:text-[12rem] font-normal text-foreground px-8 md:px-16 tracking-tight inline-block" 
              style={{ fontFamily: 'var(--font-serif)' }}
            >
              FIFTEEN •{' '}
            </span>
          </div>
          {/* Duplicate for seamless loop */}
          <div className="flex whitespace-nowrap" style={{ width: 'fit-content' }} aria-hidden="true">
            <span 
              className="text-7xl md:text-8xl lg:text-[12rem] font-normal text-foreground px-8 md:px-16 tracking-tight inline-block" 
              style={{ fontFamily: 'var(--font-serif)' }}
            >
              FIFTEEN •{' '}
            </span>
            <span 
              className="text-7xl md:text-8xl lg:text-[12rem] font-normal text-foreground px-8 md:px-16 tracking-tight inline-block" 
              style={{ fontFamily: 'var(--font-serif)' }}
            >
              FIFTEEN •{' '}
            </span>
            <span 
              className="text-7xl md:text-8xl lg:text-[12rem] font-normal text-foreground px-8 md:px-16 tracking-tight inline-block" 
              style={{ fontFamily: 'var(--font-serif)' }}
            >
              FIFTEEN •{' '}
            </span>
            <span 
              className="text-7xl md:text-8xl lg:text-[12rem] font-normal text-foreground px-8 md:px-16 tracking-tight inline-block" 
              style={{ fontFamily: 'var(--font-serif)' }}
            >
              FIFTEEN •{' '}
            </span>
          </div>
        </div>
      </div>

      {/* Subtle glow effect - digicam exposure feel */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          background: 'radial-gradient(circle at 50% 50%, hsl(210 100% 70% / 0.1) 0%, transparent 50%)',
        }}
      />

      {/* Bottom line - perfectly aligned */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-foreground/15" />
    </section>
  );
}
