import WishlistItem from "./WishlistItem";

// TODO: remove mock functionality - This is placeholder data for the prototype
const mockWishlistItems = [
  {
    id: "1",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80",
    title: "Vintage Camera",
    description: "A classic film camera to capture those nighttime city moments with authentic grain and glow.",
    price: "$299",
    link: "https://example.com",
  },
  {
    id: "2",
    image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800&q=80",
    title: "Designer Sneakers",
    description: "Clean white sneakers for late-night walks through the city streets.",
    price: "$180",
    link: "https://example.com",
  },
  {
    id: "3",
    image: "https://images.unsplash.com/photo-1511385348-a52b45bb4e9f?w=800&q=80",
    title: "Bluetooth Speaker",
    description: "Portable speaker for the perfect soundtrack to evening adventures.",
    price: "$120",
    link: "https://example.com",
  },
  {
    id: "4",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&q=80",
    title: "Minimalist Watch",
    description: "Sleek timepiece with a modern design, perfect for any occasion.",
    price: "$250",
    link: "https://example.com",
  },
  {
    id: "5",
    image: "https://images.unsplash.com/photo-1585386959984-a4155224a1ad?w=800&q=80",
    title: "Denim Jacket",
    description: "Classic denim jacket for those cool city nights and effortless style.",
    price: "$95",
    link: "https://example.com",
  },
  {
    id: "6",
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=800&q=80",
    title: "Silver Chain",
    description: "Subtle silver necklace to add a touch of sophistication to any look.",
    price: "$85",
    link: "https://example.com",
  },
];

export default function WishlistGrid() {
  return (
    <section id="wishlist" className="relative py-24 md:py-32 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-20 md:mb-28">
          <h2 
            className="text-3xl md:text-4xl font-normal tracking-[0.3em] uppercase text-foreground mb-8"
            style={{ fontFamily: 'var(--font-serif)' }}
            data-testid="text-wishlist-title"
          >
            The List
          </h2>
          <div className="full-divider" />
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 md:gap-16">
          {mockWishlistItems.map((item) => (
            <WishlistItem key={item.id} {...item} />
          ))}
        </div>
      </div>

      {/* Full width divider at bottom */}
      <div className="full-divider mt-24 md:mt-32" />
    </section>
  );
}
