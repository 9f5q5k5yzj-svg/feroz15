import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";
import { useEffect, useRef, useState } from "react";

interface WishlistItemProps {
  id: string;
  image: string;
  title: string;
  description: string;
  price: string;
  link: string;
}

export default function WishlistItem({ id, image, title, description, price, link }: WishlistItemProps) {
  const [isVisible, setIsVisible] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={cardRef}
      className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}
    >
      <div 
        className="group overflow-hidden border border-foreground/15 bg-white transition-all duration-500 hover:border-foreground/30 relative"
        data-testid={`card-wishlist-${id}`}
      >
        {/* Subtle digicam glow on hover */}
        <div 
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
          style={{
            background: 'radial-gradient(circle at 50% 50%, hsl(210 100% 80% / 0.03) 0%, transparent 70%)',
          }}
        />

        <div className="relative aspect-[3/4] overflow-hidden">
          {/* Image */}
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            data-testid={`img-wishlist-${id}`}
          />
          
          {/* Subtle film grain on image */}
          <div 
            className="absolute inset-0 opacity-[0.03] pointer-events-none mix-blend-overlay"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulance type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
            }}
          />
          
          {/* Price tag */}
          <div 
            className="absolute top-6 right-6 px-4 py-2 bg-white border border-foreground/20"
            data-testid={`text-price-${id}`}
          >
            <span className="text-sm tracking-wider text-foreground">{price}</span>
          </div>
        </div>

        <div className="p-8 space-y-5">
          <h3 
            className="text-2xl md:text-3xl font-normal text-foreground tracking-tight"
            style={{ fontFamily: 'var(--font-serif)' }}
            data-testid={`text-title-${id}`}
          >
            {title}
          </h3>
          
          <p 
            className="text-sm md:text-base text-foreground/60 leading-relaxed tracking-wide"
            data-testid={`text-description-${id}`}
          >
            {description}
          </p>

          <Button
            variant="outline"
            className="w-full group/btn tracking-[0.2em] text-xs border-foreground/20 hover:border-foreground/40 hover:bg-transparent"
            onClick={() => window.open(link, '_blank')}
            data-testid={`button-link-${id}`}
          >
            <span>VIEW ITEM</span>
            <ExternalLink className="ml-2 h-3 w-3 transition-transform group-hover/btn:translate-x-1" />
          </Button>
        </div>
      </div>
    </div>
  );
}
